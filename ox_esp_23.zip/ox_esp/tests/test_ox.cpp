#include "../src/ox_game.cpp"
#include <cstdio>
// fake memory: one local player + camera transform with a parent (yaw 90deg)
struct Fake : IMem {
    std::map<uint64_t, std::vector<uint8_t>> pg;
    template <class T> void w(uint64_t a, T v) { for (size_t i = 0; i < sizeof(T); i++) pg[(a + i) >> 12].resize(4096), pg[(a + i) >> 12][(a + i) & 4095] = ((uint8_t*)&v)[i]; }
    bool read(uint64_t a, void* o, size_t n) override { for (size_t i = 0; i < n; i++) { auto it = pg.find((a + i) >> 12); ((uint8_t*)o)[i] = it == pg.end() ? 0 : it->second.size() ? it->second[(a + i) & 4095] : 0; } return true; }
    std::vector<Region> regions() override { return {}; }
};
static int fails = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #x); fails++; } } while (0)
int main() {
    float s = std::sqrt(0.5f);
    float q90[4] = {0, s, 0, s}, id[4] = {0, 0, 0, 1}, o[4];
    qmul(q90, id, o); CHECK(std::fabs(o[1] - s) < 1e-5f && std::fabs(o[3] - s) < 1e-5f);
    Vec3 f = qrot(q90, Vec3{0, 0, 1}); CHECK(std::fabs(f.x - 1) < 1e-5f && std::fabs(f.z) < 1e-5f);
    Fake m;
    OxGame g(m, 0x1000);
    // native transform: hierarchy at H, node 1 child of node 0. node0: pos (10,0,0) rot yaw90; node1 local pos (0,0,2) identity
    uint64_t nat = 0x100000, hier = 0x200000, list = 0x300000, par = 0x400000;
    m.w<uint64_t>(nat + 0x38, hier); m.w<uint32_t>(nat + 0x40, 1);
    m.w<uint64_t>(hier + 0x18, list); m.w<uint64_t>(hier + 0x20, par);
    m.w<int32_t>(par + 0, -1); m.w<int32_t>(par + 4, 0);
    float n0[12] = {10, 0, 0, 0, 0, s, 0, s, 1, 1, 1, 0}, n1[12] = {0, 0, 2, 0, 0, 0, 0, 1, 1, 1, 1, 0};
    for (int i = 0; i < 12; i++) { m.w<float>(list + i * 4, n0[i]); m.w<float>(list + 0x30 + i * 4, n1[i]); }
    Vec3 p; float q[4];
    CHECK(g.comp_trs(0, p, q) == false);
    // component -> m_CachedPtr(+0x10)=natObj ; natObj+0x30 = go ; go+0x30 = arr ; arr+8 = nat
    uint64_t comp = 0x500000, natObj = 0x600000, go = 0x700000, arr = 0x800000;
    m.w<uint64_t>(comp + 0x10, natObj); m.w<uint64_t>(natObj + 0x30, go); m.w<uint64_t>(go + 0x30, arr); m.w<uint64_t>(arr + 8, nat);
    CHECK(g.comp_trs(comp, p, q));
    printf("pos %.2f %.2f %.2f\n", p.x, p.y, p.z);
    CHECK(std::fabs(p.x - 12) < 1e-4f && std::fabs(p.z) < 1e-4f);        // child offset (0,0,2) rotated by yaw 90 -> (2,0,0)
    Vec3 fw = qrot(q, Vec3{0, 0, 1}); CHECK(std::fabs(fw.x - 1) < 1e-4f);
    printf(fails ? "%d FAILED\n" : "all ok\n", fails);
    return fails != 0;
}
