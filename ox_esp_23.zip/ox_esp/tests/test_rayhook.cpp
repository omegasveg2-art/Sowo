#include "../src/code.cpp"
#include <cstdio>
#include <cstring>
struct Fake : IMem {
    std::map<uint64_t, uint8_t> mem;
    std::vector<Region> regs;
    bool read(uint64_t a, void* o, size_t n) override { for (size_t i = 0; i < n; i++) { auto it = mem.find(a + i); ((uint8_t*)o)[i] = it == mem.end() ? 0 : it->second; } return true; }
    bool write(uint64_t a, const void* in, size_t n) override { for (size_t i = 0; i < n; i++) mem[a + i] = ((const uint8_t*)in)[i]; return true; }
    std::vector<Region> regions() override { return regs; }
};
static int fails = 0;
#define CHECK(x) do { if (!(x)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #x); fails++; } } while (0)
int main() {
    Fake m;
    const uint64_t TEXT = 0x7000000000ull, FUNC = TEXT + 0x1000;
    Region r; r.start = TEXT; r.end = TEXT + 0x400000; r.r = true; r.x = true; r.path = "/data/app/x/lib/arm64/libil2cpp.so";
    m.regs.push_back(r);
    m.write(FUNC, "\xFD\x7B\xBF\xA9", 4);           // stp x29,x30,[sp,#-16]! -- relocatable, not pc-relative
    CodePatcher cp(m);
    RayHook h(m, cp);
    std::string err;
    CHECK(h.install(FUNC, err));
    printf("err=%s\n", err.c_str());
    // the cave must contain no store whose target is its own address range (self-modifying r-x write)
    uint32_t cave_words[RayHook::SIZE / 4];
    m.read(h.ready() ? 0 : 0, nullptr, 0);   // no-op, cave_ is private; re-find via the branch we installed
    uint32_t br; m.read(FUNC, &br, 4);
    CHECK((br & 0xFC000000u) == 0x14000000u);
    int64_t disp = (int64_t)(int32_t)((br & 0x03FFFFFF) << 6) >> 4;   // sign-extend 26-bit imm*4
    uint64_t cave = FUNC + (uint64_t)disp;
    m.read(cave, cave_words, sizeof cave_words);
    for (int i = 0; i < (int)(RayHook::SIZE / 4); i++) {
        uint32_t w = cave_words[i];
        bool isStore = (w & 0xBF800000u) == 0xBD000000u || (w & 0xBF000000u) == 0xB9000000u;   // STR (SIMD&FP / integer) unsigned-offset family, roughly
        if (isStore) CHECK((w >> 5 & 31) != 31);   // never targets a PC-relative/self address register by construction; the real guarantee is Xn==x1 (ptrReg), checked below
    }
    // the three direction stores target x1 (register 1, bits[9:5]) at +12,+16,+20 -- never the cave itself
    bool sawStores[3] = {false, false, false};
    for (int i = 0; i < (int)(RayHook::SIZE / 4); i++) {
        uint32_t w = cave_words[i];
        if ((w & 0xFFC00000u) != 0xBD000000u) continue;              // STR Sn,[Xn,#imm] unsigned-offset encoding family
        uint32_t rn = (w >> 5) & 31, imm = ((w >> 10) & 0xFFF) * 4;
        CHECK(rn == 1);
        if (imm == 12) sawStores[0] = true; if (imm == 16) sawStores[1] = true; if (imm == 20) sawStores[2] = true;
    }
    CHECK(sawStores[0] && sawStores[1] && sawStores[2]);
    h.feed(Vec3{1, 0, 0}, counter_now() + counter_freq());
    h.off();
    h.uninstall();
    uint32_t restored; m.read(FUNC, &restored, 4);
    CHECK(memcmp(&restored, "\xFD\x7B\xBF\xA9", 4) == 0);
    printf(fails ? "%d FAILED\n" : "all ok\n", fails);
    return fails != 0;
}
